package group1.service;

import group1.model.TacGia;

public class TacGiaServiceimpl implements ITacGiaService{

	@Override
	public TacGia tgia() {
		// TODO Auto-generated method stub
		return null;
	}

}
