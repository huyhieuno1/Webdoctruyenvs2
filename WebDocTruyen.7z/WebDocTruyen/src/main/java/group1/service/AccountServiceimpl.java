package group1.service;

import group1.model.Account;

public class AccountServiceimpl implements IAccountService{

	@Override
	public void save(Account dg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Account dg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Account dg) {
		// TODO Auto-generated method stub
		
	}

	
}
